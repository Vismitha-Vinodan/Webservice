/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServlet;

/**
 *
 * @author MEGHA
 */
public class DbConn extends HttpServlet{

    Connection con;
    Statement st;
    PreparedStatement pst;
    private static final int BUFFER_SIZE = 4096;
    ServletConfig config = null;

    public DbConn() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info", "root", "");

            st = con.createStatement();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public void add(String name,String email,String address) throws SQLException{
        String str1 = "INSERT INTO info.user(name,email) VALUES ('" + name + "','" + email + "')";
            st.executeUpdate(str1);
        int id=maxid();
        String str2 = "INSERT INTO info.address(uid,uaddress) VALUES ('" + id + "','" + address + "')";
            st.executeUpdate(str2);
    }
    public int maxid() throws SQLException{
        int i=0;
        String str = "select max(id) from user";
        ResultSet rs=st.executeQuery(str);
        while(rs.next()){
            i=rs.getInt(1);
        }
        return i;
    }
    
    public void edit(int id,String name,String email,String address) throws SQLException{
        String str = "UPDATE info.user SET `name` = '" + name + "',`email` = '" + email + "' WHERE `id` = '" + id + "'";
            st.executeUpdate(str);
            String str1 = "UPDATE info.address SET `uaddress` = '" + address +"' WHERE `uid` = '" + id + "'";
            st.executeUpdate(str1);
    }
    public void delete(int id) throws SQLException{
        String str = "delete from info.address where uid="+id;
            st.executeUpdate(str);
        String str1 = "delete from info.user where id="+id;
            st.executeUpdate(str1);
    }
    public ResultSet display() throws SQLException{
        String str = "select id,name,email,uaddress from info.user join info.address";
            ResultSet rs = st.executeQuery(str);
            return rs;
    }
    public ResultSet editdisplay(String id) throws SQLException{
        String str = "select id,name,email,uaddress from info.user join info.address where user.id="+id;
            ResultSet rs = st.executeQuery(str);
            return rs;
    }
}

